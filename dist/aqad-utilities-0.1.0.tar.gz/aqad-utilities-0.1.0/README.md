# aqad-utilities

[![Testing aqad-utilities](https://github.com/mohit2152sharma/aqad-utilities/actions/workflows/python-package-testing.yml/badge.svg)](https://github.com/mohit2152sharma/aqad-utilities/actions/workflows/python-package-testing.yml)

A utilities package for A Question A Day (aqad). This package contains the function for splitting text within twitter character limit, some functions for extracting code from text.    